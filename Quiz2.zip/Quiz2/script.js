const students = JSON.parse(localStorage.getItem("students")) || {
  "20128971": {
      fullName: "Tonata",
      caMark: null,
      examMark: null,
      finalMark: null,
      grade: null,
  },
  "20120881": {
      fullName: "Ton-ton",
      caMark: null,
      examMark: null,
      finalMark: null,
      grade: null,
  },
  "21982717": {
      fullName: "Richard",
      caMark: null,
      examMark: null,
      finalMark: null,
      grade: null,
  },
  "218203080": {
      fullName: "Olivia Angula",
      caMark: null,
      examMark: null,
      finalMark: null,
      grade: null,
  },
  "20121111": {
      fullName: "Jane Teo",
      caMark: null,
      examMark: null,
      finalMark: null,
      grade: null,
  },
};

window.onload = function () {
  const studentMarksTable = document.getElementById("studentMarksTableBody");

  for (const studentNumber in students) {
      const student = students[studentNumber];

      const tableRow = document.createElement("tr");

      const studentNumberCell = document.createElement("td");
      const fullNameCell = document.createElement("td");
      const caMarkCell = document.createElement("td");
      caMarkCell.setAttribute("contenteditable", "true");
      const examMarkCell = document.createElement("td");
      examMarkCell.setAttribute("contenteditable", "true");
      const finalMarkCell = document.createElement("td");
      const gradeCell = document.createElement("td");

      studentNumberCell.textContent = studentNumber;
    fullNameCell.textContent = student.fullName;
    caMarkCell.textContent = student.caMark || ""; 
    examMarkCell.textContent = student.examMark || ""; 
    finalMarkCell.textContent = student.finalMark || "";
    gradeCell.textContent = student.grade || "";

      tableRow.appendChild(studentNumberCell);
      tableRow.appendChild(fullNameCell);
      tableRow.appendChild(caMarkCell);
      tableRow.appendChild(examMarkCell);
      tableRow.appendChild(finalMarkCell);
      tableRow.appendChild(gradeCell);

      studentMarksTable.appendChild(tableRow);

      
      examMarkCell.addEventListener("input", function () {
        student.examMark = examMarkCell.textContent.trim();
          calculateFinalMarkAndGrade(studentNumber, caMarkCell, examMarkCell, finalMarkCell, gradeCell);
      });

      caMarkCell.addEventListener("input", function () {
        student.caMark = caMarkCell.textContent.trim();
          calculateFinalMarkAndGrade(studentNumber, caMarkCell, examMarkCell, finalMarkCell, gradeCell);
      });
  }
};


function calculateFinalMarkAndGrade(studentNumber, caMarkCell, examMarkCell, finalMarkCell, gradeCell) {
  const student = students[studentNumber];
  const caMarkText = caMarkCell.textContent.trim();
  const examMarkText = examMarkCell.textContent.trim();

 
  if (caMarkText === "" || examMarkText === "") {
      return;
  }

  const caMarks = parseFloat(caMarkText);
  const examMarks = parseFloat(examMarkText);

  if (isNaN(caMarks) || isNaN(examMarks)) {
      return;
  }

  const caWeight = 0.5;
  const examWeight = 0.5;

  const totalCA = (caMarks * caWeight);
  const totalExam = (examMarks * examWeight);

  const finalMark = (totalCA + totalExam).toFixed(1);
  student.finalMark = finalMark;
  student.grade = calculateGrade(finalMark);

  finalMarkCell.textContent = student.finalMark;
  gradeCell.textContent = student.grade;

  
  localStorage.setItem("students", JSON.stringify(students));
}


function calculateGrade(finalMark) {
  let grade;

  if (finalMark >= 80) {
      grade = "Excellent ";
  } else if (finalMark >= 60) {
      grade = "Very Good";
  } else if (finalMark >= 50) {
      grade = "Good";
  } else if (finalMark >= 46) {
      grade = "Qualifies for Sup";
  } else {
      grade = "Fail";
  }

  return grade;
}

